from flask import render_template, url_for, redirect
from application import app, db
from application.models import SearchCard
from application.forms import SearchCardForm, SearchByForm 

@app.route('/')
@app.route('/home', methods=['GET'])
def home():
	srchbyfrm = SearchByForm()
	if srchbyfrm.validate_on_submit():
		if srchbyfrm.by_name:
			return render_template('byname.html', title='Home: Search By Name', form=srchcrdfrm)
	return render_template('home.html', title='Home', form=srchbyfrm)

@app.route('/home/by_name', methods=['GET'])
def byname():
	srchcrdfrm = SearchCardForm()
	return render_template('byname.html', title='Home: Search By Name', form=srchcrdfrm)