from flask import render_template, url_for
from application import app, db
from application.models import SearchCard
from application.forms import SearchCardForm, SearchByForm

@app.route('/')
@app.route('/home')
def home():
	form = SearchCardForm()
	form2 = SearchByForm()
	return render_template('home.html', title='Home', form=form, form2=form2)